//
//  ViewController.swift
//  OpenAppAds
//
//  Created by MacBook Pro on 16/04/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) {
//            if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
//                appDelegate.window?.rootViewController = self
//                appDelegate.appOpenAd?.present(fromRootViewController: self)
//            }
//        }
    }

}

