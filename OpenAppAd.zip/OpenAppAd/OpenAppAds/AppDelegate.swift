import GoogleMobileAds
@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    //var appOpenAd: GADAppOpenAd?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        GADMobileAds.sharedInstance().start(completionHandler: nil)
        DispatchQueue.global().async {
            
            //self.loadAd()
        }
        return true
    }
    /*
    func loadAd() {
        let adRequest = GADRequest()
        GADAppOpenAd.load(withAdUnitID: "ca-app-pub-3940256099942544/5575463023",
                          request: adRequest,
                          completionHandler: { (ad, error) in
            if let error = error {
                print("Failed to load ad:", error.localizedDescription)
                return
            }
            self.appOpenAd = ad
          
        })
    }

    func showAdIfAvailable() {
        if let ad = appOpenAd {
            ad.present(fromRootViewController: window?.rootViewController ?? UIViewController())
        } else {
            print("Ad wasn't ready")
        }
    }*/
    
    

}
